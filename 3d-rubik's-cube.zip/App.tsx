import React, { useState, useCallback, useRef, useEffect } from 'react';
import Cube, { CubeHandle } from './components/Cube';
import { useCubeState } from './hooks/useCubeState';
import { FaceControls } from './components/FaceControls';
import { SolvedModal } from './components/SolvedModal';
import { HowToPlayModal } from './components/HowToPlayModal';
import { playCubeClickSound } from './sound';
import { Axis, MoveNotation, STANDARD_MOVES } from './types';
import confetti from 'canvas-confetti';
import { HelpCircle, Timer, Hash, ZoomIn, ZoomOut, Maximize2, Eye, EyeOff } from 'lucide-react';

export default function App() {
  const {
    cubeState,
    rotateFace,
    undo,
    reset,
    moveCount,
    historyLength,
    isSolved,
    isScrambled,
    setIsScrambled,
  } = useCubeState();

  const cubeRef = useRef<CubeHandle>(null);

  const [showInfo, setShowInfo] = useState<boolean>(false);
  const [showSolvedModal, setShowSolvedModal] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [isScrambling, setIsScrambling] = useState<boolean>(false);
  const [isUiHidden, setIsUiHidden] = useState<boolean>(false);

  // Timer state
  const [timerSeconds, setTimerSeconds] = useState<number>(0);
  const [timerRunning, setTimerRunning] = useState<boolean>(false);
  const timerIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Format timer MM:SS.S
  const formatTime = (totalSec: number) => {
    const mins = Math.floor(totalSec / 60);
    const secs = Math.floor(totalSec % 60);
    const tenths = Math.floor((totalSec * 10) % 10);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}.${tenths}`;
  };

  // High-performance timer ticker
  useEffect(() => {
    if (timerRunning) {
      const startTime = Date.now() - timerSeconds * 1000;
      timerIntervalRef.current = setInterval(() => {
        setTimerSeconds((Date.now() - startTime) / 1000);
      }, 100);
    } else if (timerIntervalRef.current) {
      clearInterval(timerIntervalRef.current);
    }

    return () => {
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
      }
    };
  }, [timerRunning, timerSeconds]);

  // Handle slice rotation from interactive gestures or buttons
  const handleRotateFace = useCallback((axis: Axis, slice: number, direction: 1 | -1) => {
    rotateFace(axis, slice, direction);

    // Start timer on first player action if scrambled
    if (isScrambled && !timerRunning) {
      setTimerRunning(true);
    }

    if (soundEnabled) {
      playCubeClickSound();
    }
  }, [rotateFace, isScrambled, timerRunning, soundEnabled]);

  // Face buttons trigger move
  const handleButtonMove = useCallback((axis: Axis, slice: number, direction: 1 | -1) => {
    if (cubeRef.current) {
      cubeRef.current.triggerMove(axis, slice, direction);
    } else {
      handleRotateFace(axis, slice, direction);
    }
  }, [handleRotateFace]);

  // Undo wrapper
  const handleUndo = useCallback(() => {
    undo();
    if (soundEnabled) {
      playCubeClickSound();
    }
  }, [undo, soundEnabled]);

  // Reset cube
  const handleReset = useCallback(() => {
    reset();
    setTimerRunning(false);
    setTimerSeconds(0);
    setShowSolvedModal(false);
    if (cubeRef.current) {
      cubeRef.current.resetView();
    }
  }, [reset]);

  // Scramble animation & scramble execution
  const handleScramble = useCallback(async () => {
    if (isScrambling) return;
    setIsScrambling(true);
    setTimerRunning(false);
    setTimerSeconds(0);
    setShowSolvedModal(false);

    const axes: Axis[] = ['x', 'y', 'z'];
    const slices = [-1, 0, 1];
    const directions: Array<1 | -1> = [1, -1];

    const SCRAMBLE_LENGTH = 16;
    for (let i = 0; i < SCRAMBLE_LENGTH; i++) {
      const axis = axes[Math.floor(Math.random() * axes.length)];
      const slice = slices[Math.floor(Math.random() * slices.length)];
      const direction = directions[Math.floor(Math.random() * directions.length)];

      rotateFace(axis, slice, direction, false);
      if (soundEnabled && i % 3 === 0) {
        playCubeClickSound();
      }
      await new Promise(r => setTimeout(r, 40));
    }

    setIsScrambled(true);
    setIsScrambling(false);
  }, [isScrambling, rotateFace, soundEnabled, setIsScrambled]);

  // Comprehensive Desktop & Laptop Keyboard Controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if user is typing in an input
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;

      const key = e.key;

      // 1. Toggle UI visibility
      if (key === 'h' || key === 'H') {
        setIsUiHidden(prev => !prev);
        return;
      }

      // 2. Escape closes modals or unhides UI
      if (key === 'Escape') {
        setShowInfo(false);
        setShowSolvedModal(false);
        return;
      }

      // 3. Spacebar to scramble
      if (e.code === 'Space') {
        e.preventDefault();
        handleScramble();
        return;
      }

      // 4. Undo: Z, Ctrl+Z, Meta+Z, Backspace
      if ((e.ctrlKey || e.metaKey) && (key === 'z' || key === 'Z')) {
        e.preventDefault();
        handleUndo();
        return;
      }
      if (key === 'z' && !e.shiftKey && !e.altKey) {
        handleUndo();
        return;
      }

      // 5. Camera view presets: 1 (Iso), 2 (Front), 3 (Top), 4 (Right)
      if (key === '1') { cubeRef.current?.setView('isometric'); return; }
      if (key === '2') { cubeRef.current?.setView('front'); return; }
      if (key === '3') { cubeRef.current?.setView('top'); return; }
      if (key === '4') { cubeRef.current?.setView('right'); return; }

      // 6. Zoom controls: +, =, -, _, 0
      if (key === '+' || key === '=') { cubeRef.current?.zoomIn(); return; }
      if (key === '-' || key === '_') { cubeRef.current?.zoomOut(); return; }
      if (key === '0') { cubeRef.current?.resetZoom(); return; }

      // 7. Arrow keys: 3D Camera Orbit
      if (key === 'ArrowLeft') { e.preventDefault(); cubeRef.current?.orbitBy(15, 0); return; }
      if (key === 'ArrowRight') { e.preventDefault(); cubeRef.current?.orbitBy(-15, 0); return; }
      if (key === 'ArrowUp') { e.preventDefault(); cubeRef.current?.orbitBy(0, 15); return; }
      if (key === 'ArrowDown') { e.preventDefault(); cubeRef.current?.orbitBy(0, -15); return; }

      // 8. Speedcube Face Moves: U, L, F, R, B, D (Shift for prime/counter-clockwise)
      const upperKey = key.toUpperCase();
      if (['U', 'L', 'F', 'R', 'B', 'D'].includes(upperKey)) {
        e.preventDefault();
        const isCounterClockwise = e.shiftKey;
        const notation = (isCounterClockwise ? `${upperKey}'` : upperKey) as MoveNotation;
        const move = STANDARD_MOVES[notation];
        if (move) {
          handleButtonMove(move.axis, move.slice, move.direction);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleScramble, handleUndo, handleButtonMove]);

  // Detect solve
  useEffect(() => {
    if (isSolved && isScrambled && moveCount > 0) {
      setTimerRunning(false);
      setShowSolvedModal(true);

      try {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#22c55e', '#3b82f6', '#ef4444', '#facc15', '#fb923c', '#ffffff'],
        });
      } catch {
        // Fallback
      }
    }
  }, [isSolved, isScrambled, moveCount]);

  return (
    <div
      className="w-screen h-screen flex flex-col text-neutral-100 overflow-hidden select-none touch-none perspective-1000 relative"
      style={{
        background: 'radial-gradient(circle at 50% 20%, #111524 0%, #090a0f 65%)',
      }}
    >
      {/* Persistent Show UI Button when menus are hidden */}
      {isUiHidden && (
        <button
          id="btn-show-menus"
          onClick={() => setIsUiHidden(false)}
          className="fixed top-[max(0.85rem,env(safe-area-inset-top))] right-[max(1rem,env(safe-area-inset-right))] z-50 flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-[#11131a]/92 hover:bg-[#1a1e2b] border border-[#2a3042] text-white shadow-2xl backdrop-blur-md transition-all duration-200 active:scale-95 group"
          title="Show all menus and buttons (Press H)"
          aria-label="Show all menus and buttons"
        >
          <div className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
          <Eye className="w-4 h-4 text-blue-400 group-hover:scale-110 transition" />
          <span className="text-xs font-bold tracking-wide">Show Menus</span>
        </button>
      )}

      {/* Top Header Bar (Responsive across phones, pads & computers) */}
      {!isUiHidden && (
        <header className="relative z-20 w-full pt-[max(0.6rem,env(safe-area-inset-top))] pb-1.5 px-[max(0.75rem,env(safe-area-inset-left))] flex items-center justify-between gap-2 max-w-4xl mx-auto transition-all duration-200">
          {/* Brand / Status */}
          <div className="flex items-center gap-2 sm:gap-2.5">
            <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center shadow-md shadow-blue-500/20 border border-white/20">
              <div className="w-3.5 h-3.5 sm:w-4 sm:h-4 border-2 border-white rotate-12 rounded-[2px]" />
            </div>
            <div>
              <h1 className="font-extrabold text-xs sm:text-base tracking-tight text-white leading-tight">
                Rubik's 3D
              </h1>
              <span className="text-[9px] sm:text-[10px] tracking-wide block">
                {isSolved ? (
                  <span className="text-emerald-400 font-bold flex items-center gap-1">
                    ● Solved
                  </span>
                ) : (
                  <span className="text-neutral-400 font-medium">
                    {isScrambled ? 'Scrambled' : 'Standard'}
                  </span>
                )}
              </span>
            </div>
          </div>

          {/* Stats Badges: Timer & Moves */}
          <div className="flex items-center gap-1.5 sm:gap-3">
            {/* Move Counter */}
            <div
              className="flex items-center gap-1 sm:gap-1.5 px-2 sm:px-2.5 py-1 sm:py-1.5 rounded-xl bg-[#11131a] border border-[#242836] shadow-inner text-neutral-300"
              title="Move counter"
            >
              <Hash className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-blue-400" />
              <span className="text-[11px] sm:text-xs font-mono font-semibold tracking-wider text-white">
                {moveCount}
              </span>
            </div>

            {/* Timer */}
            <div
              className="flex items-center gap-1 sm:gap-1.5 px-2 sm:px-2.5 py-1 sm:py-1.5 rounded-xl bg-[#11131a] border border-[#242836] shadow-inner text-neutral-300"
              title="Solve timer"
            >
              <Timer className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-emerald-400" />
              <span className="text-[11px] sm:text-xs font-mono font-semibold tracking-wider text-white">
                {formatTime(timerSeconds)}
              </span>
            </div>
          </div>

          {/* Right Action Buttons: Hide UI & Info */}
          <div className="flex items-center gap-1 sm:gap-1.5">
            {/* Hide All Menus Button */}
            <button
              id="btn-hide-menus"
              onClick={() => setIsUiHidden(true)}
              className="p-1.5 sm:p-2 rounded-xl text-neutral-300 hover:text-white bg-[#11131a] hover:bg-[#1a1d27] border border-[#242836] transition shadow-sm active:scale-95 flex items-center gap-1"
              title="Hide all menus for a clean view (Press H)"
              aria-label="Hide all menus and buttons"
            >
              <EyeOff className="w-4 h-4 sm:w-5 sm:h-5 text-neutral-300 hover:text-white" />
              <span className="hidden lg:inline text-[11px] font-medium text-neutral-400">Hide UI</span>
            </button>

            {/* Help / Instructions Modal Trigger */}
            <button
              id="btn-how-to-play"
              onClick={() => setShowInfo(true)}
              className="p-1.5 sm:p-2 rounded-xl text-neutral-300 hover:text-white bg-[#11131a] hover:bg-[#1a1d27] border border-[#242836] transition shadow-sm active:scale-95"
              title="How to play, zoom & controls"
              aria-label="How to play, zoom & controls"
            >
              <HelpCircle className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
          </div>
        </header>
      )}

      {/* 3D Rubik's Cube Main Stage */}
      <main className="flex-1 w-full relative flex items-center justify-center overflow-hidden">
        <Cube
          ref={cubeRef}
          cubeState={cubeState}
          onRotateFace={handleRotateFace}
        />

        {/* Floating Quick Zoom Controls (Responsive for mobile, pad & computer) */}
        {!isUiHidden && (
          <aside
            aria-label="Zoom controls"
            className="absolute right-2 sm:right-3.5 top-1/2 -translate-y-1/2 z-10 flex flex-col gap-1 sm:gap-1.5 bg-[#11131a]/85 border border-[#242836] rounded-2xl p-1 shadow-lg pointer-events-auto transition-all duration-200"
          >
            <button
              id="stage-zoom-in"
              onClick={() => cubeRef.current?.zoomIn()}
              className="p-1.5 sm:p-2 rounded-xl text-neutral-300 hover:text-white hover:bg-[#1f2433] active:scale-95 transition"
              title="Zoom In (+ key or 2-finger pinch)"
              aria-label="Zoom in"
            >
              <ZoomIn className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            </button>
            <button
              id="stage-reset-zoom"
              onClick={() => cubeRef.current?.resetZoom()}
              className="p-1.5 sm:p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-[#1f2433] active:scale-95 transition"
              title="Reset Zoom to 100% (0 key)"
              aria-label="Reset zoom"
            >
              <Maximize2 className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
            </button>
            <button
              id="stage-zoom-out"
              onClick={() => cubeRef.current?.zoomOut()}
              className="p-1.5 sm:p-2 rounded-xl text-neutral-300 hover:text-white hover:bg-[#1f2433] active:scale-95 transition"
              title="Zoom Out (- key or 2-finger pinch)"
              aria-label="Zoom out"
            >
              <ZoomOut className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            </button>
          </aside>
        )}
      </main>

      {/* Bottom Dock (Responsive for mobile phones, pads & computers) */}
      {!isUiHidden && (
        <footer className="relative z-20 w-full pb-[max(0.4rem,env(safe-area-inset-bottom))] pt-1 transition-all duration-200">
          <FaceControls
            onMove={handleButtonMove}
            onUndo={handleUndo}
            onScramble={handleScramble}
            onReset={handleReset}
            onViewChange={(view) => cubeRef.current?.setView(view)}
            onZoomIn={() => cubeRef.current?.zoomIn()}
            onZoomOut={() => cubeRef.current?.zoomOut()}
            canUndo={historyLength > 0}
            isScrambling={isScrambling}
            soundEnabled={soundEnabled}
            onToggleSound={() => setSoundEnabled(s => !s)}
          />
        </footer>
      )}

      {/* Solved Celebration Modal */}
      {showSolvedModal && (
        <SolvedModal
          moveCount={moveCount}
          timeFormatted={formatTime(timerSeconds)}
          onScramble={handleScramble}
          onReset={handleReset}
          onClose={() => setShowSolvedModal(false)}
        />
      )}

      {/* How to Play Instructions Modal */}
      {showInfo && (
        <HowToPlayModal onClose={() => setShowInfo(false)} />
      )}
    </div>
  );
}
