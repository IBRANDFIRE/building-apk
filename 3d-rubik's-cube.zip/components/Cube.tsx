import React, { useState, useRef, useCallback, useEffect, useImperativeHandle, forwardRef } from 'react';
import { Cubie } from './Cubie';
import { CubeState, FaceRotation, Axis, FaceName, CubieState } from '../types';

export interface CubeHandle {
  triggerMove: (axis: Axis, slice: number, direction: 1 | -1) => boolean;
  resetView: () => void;
  setView: (view: 'isometric' | 'front' | 'top' | 'right') => void;
  zoomIn: () => void;
  zoomOut: () => void;
  resetZoom: () => void;
  orbitBy: (dx: number, dy: number) => void;
}

interface CubeProps {
  cubeState: CubeState;
  onRotateFace: (axis: Axis, slice: number, direction: 1 | -1) => void;
  onAnimationStateChange?: (isAnimating: boolean) => void;
}

const CUBE_GAP = 2; // 2px authentic mechanical gap
const DRAG_THRESHOLD = 12; // pixels to distinguish tap from drag
const MIN_ZOOM = 0.55;
const MAX_ZOOM = 2.3;
const DEFAULT_ZOOM = 1.0;

/**
 * Translates 2D pointer swipe on a 3D face into a 3D slice rotation.
 */
const getRotationFromDrag = (
  face: FaceName,
  cubiePos: [number, number, number],
  dx: number,
  dy: number
): FaceRotation | null => {
  const absX = Math.abs(dx);
  const absY = Math.abs(dy);
  const isHorizontal = absX > absY;

  switch (face) {
    case 'F': {
      // Front face (Z = 1)
      if (isHorizontal) {
        return {
          axis: 'y',
          slice: cubiePos[1],
          direction: dx > 0 ? 1 : -1,
        };
      } else {
        return {
          axis: 'x',
          slice: cubiePos[0],
          direction: dy < 0 ? 1 : -1,
        };
      }
    }
    case 'B': {
      // Back face (Z = -1)
      if (isHorizontal) {
        return {
          axis: 'y',
          slice: cubiePos[1],
          direction: dx > 0 ? 1 : -1,
        };
      } else {
        return {
          axis: 'x',
          slice: cubiePos[0],
          direction: dy < 0 ? -1 : 1,
        };
      }
    }
    case 'R': {
      // Right face (X = 1)
      if (isHorizontal) {
        return {
          axis: 'y',
          slice: cubiePos[1],
          direction: dx > 0 ? 1 : -1,
        };
      } else {
        return {
          axis: 'z',
          slice: cubiePos[2],
          direction: dy < 0 ? -1 : 1,
        };
      }
    }
    case 'L': {
      // Left face (X = -1)
      if (isHorizontal) {
        return {
          axis: 'y',
          slice: cubiePos[1],
          direction: dx > 0 ? 1 : -1,
        };
      } else {
        return {
          axis: 'z',
          slice: cubiePos[2],
          direction: dy < 0 ? 1 : -1,
        };
      }
    }
    case 'U': {
      // Up face (Y = -1)
      if (isHorizontal) {
        return {
          axis: 'z',
          slice: cubiePos[2],
          direction: dx > 0 ? 1 : -1,
        };
      } else {
        return {
          axis: 'x',
          slice: cubiePos[0],
          direction: dy < 0 ? 1 : -1,
        };
      }
    }
    case 'D': {
      // Down face (Y = 1)
      if (isHorizontal) {
        return {
          axis: 'z',
          slice: cubiePos[2],
          direction: dx > 0 ? -1 : 1,
        };
      } else {
        return {
          axis: 'x',
          slice: cubiePos[0],
          direction: dy < 0 ? -1 : 1,
        };
      }
    }
    default:
      return null;
  }
};

export const Cube = forwardRef<CubeHandle, CubeProps>(({
  cubeState,
  onRotateFace,
  onAnimationStateChange,
}, ref) => {
  const stageRef = useRef<HTMLDivElement>(null);
  const worldRef = useRef<HTMLDivElement>(null);

  // Rotation angles & zoom scale in refs for 60/120fps direct hardware rendering
  const rotationRef = useRef({ x: -26, y: 38 });
  const zoomScaleRef = useRef(DEFAULT_ZOOM);
  const rafIdRef = useRef<number | null>(null);

  // Active rotation state & queue for slice turns
  const [activeRotation, setActiveRotation] = useState<FaceRotation | null>(null);
  const activeRotationRef = useRef<FaceRotation | null>(null);
  activeRotationRef.current = activeRotation;

  const moveQueue = useRef<FaceRotation[]>([]);
  const animationTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Dynamic responsive cubie size with ResizeObserver across mobile, pads & computer monitors
  const [cubieSize, setCubieSize] = useState(64);

  useEffect(() => {
    const stage = stageRef.current;
    if (!stage) return;

    const computeSize = () => {
      const rect = stage.getBoundingClientRect();
      const stageW = rect.width || window.innerWidth;
      const stageH = rect.height || (window.innerHeight - 150);
      const minDimension = Math.min(stageW, stageH);

      // Low-height landscape (smartphones sideways, small pad split screen)
      if (stageH < 350) {
        setCubieSize(Math.max(38, Math.min(50, Math.floor(stageH / 5.2))));
      }
      // Small mobile phones (portrait iPhone SE, small Androids)
      else if (minDimension < 380) {
        setCubieSize(50);
      }
      // Standard mobile phones (iPhone 12/13/14/15/16, Samsung Galaxy)
      else if (minDimension < 520) {
        setCubieSize(58);
      }
      // Large phones & compact pads (iPhone Pro Max, iPad Mini)
      else if (minDimension < 768) {
        setCubieSize(66);
      }
      // Tablets / Mobile Pads (iPad 10.2", iPad Air, iPad Pro, Galaxy Tab)
      else if (minDimension < 1080) {
        setCubieSize(74);
      }
      // Desktop / Laptops / Large Monitors
      else {
        setCubieSize(80);
      }
    };

    computeSize();

    const resizeObserver = new ResizeObserver(() => {
      computeSize();
    });
    resizeObserver.observe(stage);

    window.addEventListener('resize', computeSize);
    window.addEventListener('orientationchange', computeSize);

    return () => {
      resizeObserver.disconnect();
      window.removeEventListener('resize', computeSize);
      window.removeEventListener('orientationchange', computeSize);
    };
  }, []);

  // Update world transform without React state re-renders
  const updateWorldTransform = useCallback((withTransition = false) => {
    if (worldRef.current) {
      worldRef.current.style.transition = withTransition
        ? 'transform 0.35s cubic-bezier(0.2, 0.8, 0.2, 1)'
        : 'none';
      worldRef.current.style.transform = `scale3d(${zoomScaleRef.current}, ${zoomScaleRef.current}, ${zoomScaleRef.current}) rotateX(${rotationRef.current.x}deg) rotateY(${rotationRef.current.y}deg)`;
    }
  }, []);

  useEffect(() => {
    onAnimationStateChange?.(!!activeRotation);
  }, [activeRotation, onAnimationStateChange]);

  // Execute or enqueue a move
  const triggerMove = useCallback((axis: Axis, slice: number, direction: 1 | -1): boolean => {
    if (activeRotationRef.current) {
      if (moveQueue.current.length < 8) {
        moveQueue.current.push({ axis, slice, direction });
        return true;
      }
      return false;
    }

    setActiveRotation({ axis, slice, direction });
    return true;
  }, []);

  // Complete rotation and process queue
  const finishActiveRotation = useCallback(() => {
    if (animationTimerRef.current) {
      clearTimeout(animationTimerRef.current);
      animationTimerRef.current = null;
    }

    const current = activeRotationRef.current;
    if (current) {
      onRotateFace(current.axis, current.slice, current.direction);
      setActiveRotation(null);

      // Process next queued move if present
      if (moveQueue.current.length > 0) {
        const next = moveQueue.current.shift()!;
        requestAnimationFrame(() => {
          setActiveRotation(next);
        });
      }
    }
  }, [onRotateFace]);

  // Safety timer for keyframe animation
  useEffect(() => {
    if (activeRotation) {
      animationTimerRef.current = setTimeout(() => {
        finishActiveRotation();
      }, 250);

      return () => {
        if (animationTimerRef.current) {
          clearTimeout(animationTimerRef.current);
        }
      };
    }
  }, [activeRotation, finishActiveRotation]);

  // Apply preset orientation smoothly
  const applyViewPreset = useCallback((x: number, y: number) => {
    rotationRef.current = { x, y };
    updateWorldTransform(true);
  }, [updateWorldTransform]);

  // Zoom helpers
  const changeZoom = useCallback((delta: number) => {
    const newZoom = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, zoomScaleRef.current + delta));
    zoomScaleRef.current = newZoom;
    updateWorldTransform(true);
  }, [updateWorldTransform]);

  // Expose methods to parent
  useImperativeHandle(ref, () => ({
    triggerMove,
    resetView: () => {
      zoomScaleRef.current = DEFAULT_ZOOM;
      applyViewPreset(-26, 38);
    },
    setView: (view: 'isometric' | 'front' | 'top' | 'right') => {
      switch (view) {
        case 'isometric':
          applyViewPreset(-26, 38);
          break;
        case 'front':
          applyViewPreset(0, 0);
          break;
        case 'top':
          applyViewPreset(-75, 0);
          break;
        case 'right':
          applyViewPreset(0, -90);
          break;
      }
    },
    zoomIn: () => changeZoom(0.2),
    zoomOut: () => changeZoom(-0.2),
    resetZoom: () => {
      zoomScaleRef.current = DEFAULT_ZOOM;
      updateWorldTransform(true);
    },
    orbitBy: (dx: number, dy: number) => {
      rotationRef.current.x = Math.max(-82, Math.min(82, rotationRef.current.x - dy));
      rotationRef.current.y = (rotationRef.current.y + dx) % 360;
      updateWorldTransform(true);
    },
  }), [triggerMove, applyViewPreset, changeZoom, updateWorldTransform]);

  // -------------------------------------------------------------
  // BULLETPROOF TOUCH EVENT SYSTEM (Mobile & Pad Gestures)
  // -------------------------------------------------------------
  useEffect(() => {
    const stage = stageRef.current;
    if (!stage) return;

    let isPinching = false;
    let pinchStartDist = 0;
    let pinchStartScale = DEFAULT_ZOOM;

    let touchFaceDrag: {
      startX: number;
      startY: number;
      cubiePos: [number, number, number];
      face: FaceName;
    } | null = null;

    let touchOrbitStart: { x: number; y: number } | null = null;

    const onTouchStart = (e: TouchEvent) => {
      e.preventDefault();

      // Case 1: 2 or more fingers touching -> ZOOM MODE
      if (e.touches.length >= 2) {
        isPinching = true;
        touchFaceDrag = null;
        touchOrbitStart = null;

        const t0 = e.touches[0];
        const t1 = e.touches[1];
        pinchStartDist = Math.hypot(t0.clientX - t1.clientX, t0.clientY - t1.clientY);
        pinchStartScale = zoomScaleRef.current;

        if (worldRef.current) {
          worldRef.current.style.transition = 'none';
        }
        return;
      }

      // Case 2: Exactly 1 finger touching
      isPinching = false;
      pinchStartDist = 0;

      const touch = e.touches[0];
      const target = touch.target as HTMLElement | null;
      const faceEl = target?.closest('[data-face]') as HTMLElement | null;

      if (faceEl && !activeRotationRef.current) {
        const face = faceEl.getAttribute('data-face') as FaceName;
        const posStr = faceEl.getAttribute('data-pos');
        if (face && posStr) {
          const [px, py, pz] = posStr.split(',').map(Number);
          touchFaceDrag = {
            startX: touch.clientX,
            startY: touch.clientY,
            cubiePos: [px, py, pz],
            face,
          };
          return;
        }
      }

      // Background orbit
      touchOrbitStart = { x: touch.clientX, y: touch.clientY };
      if (worldRef.current) {
        worldRef.current.style.transition = 'none';
      }
    };

    const onTouchMove = (e: TouchEvent) => {
      e.preventDefault();

      // Sub-case: 2 fingers active -> PINCH ZOOM
      if (e.touches.length >= 2) {
        if (!isPinching || pinchStartDist <= 0) {
          isPinching = true;
          const t0 = e.touches[0];
          const t1 = e.touches[1];
          pinchStartDist = Math.hypot(t0.clientX - t1.clientX, t0.clientY - t1.clientY);
          pinchStartScale = zoomScaleRef.current;
          return;
        }

        const t0 = e.touches[0];
        const t1 = e.touches[1];
        const currentDist = Math.hypot(t0.clientX - t1.clientX, t0.clientY - t1.clientY);

        if (pinchStartDist > 0) {
          const ratio = currentDist / pinchStartDist;
          const newZoom = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, pinchStartScale * ratio));
          zoomScaleRef.current = newZoom;

          if (!rafIdRef.current) {
            rafIdRef.current = requestAnimationFrame(() => {
              updateWorldTransform(false);
              rafIdRef.current = null;
            });
          }
        }
        return;
      }

      // If NOT 2 fingers, pinching is strictly terminated!
      if (isPinching) {
        isPinching = false;
        pinchStartDist = 0;
        // If 1 finger remains on screen, initialize its anchor so it doesn't jump
        if (e.touches.length === 1) {
          touchOrbitStart = { x: e.touches[0].clientX, y: e.touches[0].clientY };
        }
        return;
      }

      // Single finger face slice turn
      if (e.touches.length === 1 && touchFaceDrag) {
        const touch = e.touches[0];
        const dx = touch.clientX - touchFaceDrag.startX;
        const dy = touch.clientY - touchFaceDrag.startY;

        if (Math.abs(dx) > DRAG_THRESHOLD || Math.abs(dy) > DRAG_THRESHOLD) {
          const { face, cubiePos } = touchFaceDrag;
          const move = getRotationFromDrag(face, cubiePos, dx, dy);
          if (move) {
            triggerMove(move.axis, move.slice, move.direction);
          }
          touchFaceDrag = null;
        }
        return;
      }

      // Single finger camera orbit
      if (e.touches.length === 1 && touchOrbitStart) {
        const touch = e.touches[0];
        const dx = touch.clientX - touchOrbitStart.x;
        const dy = touch.clientY - touchOrbitStart.y;
        touchOrbitStart = { x: touch.clientX, y: touch.clientY };

        rotationRef.current.x = Math.max(-82, Math.min(82, rotationRef.current.x - dy * 0.42));
        rotationRef.current.y = (rotationRef.current.y + dx * 0.42) % 360;

        if (!rafIdRef.current) {
          rafIdRef.current = requestAnimationFrame(() => {
            updateWorldTransform(false);
            rafIdRef.current = null;
          });
        }
      }
    };

    const onTouchEnd = (e: TouchEvent) => {
      // When all fingers lifted, clear everything cleanly
      if (e.touches.length === 0) {
        isPinching = false;
        pinchStartDist = 0;
        touchFaceDrag = null;
        touchOrbitStart = null;
        return;
      }

      // When 1 finger remains after pinch
      if (e.touches.length === 1) {
        isPinching = false;
        pinchStartDist = 0;
        touchFaceDrag = null;
        touchOrbitStart = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      }
    };

    stage.addEventListener('touchstart', onTouchStart, { passive: false });
    stage.addEventListener('touchmove', onTouchMove, { passive: false });
    stage.addEventListener('touchend', onTouchEnd, { passive: false });
    stage.addEventListener('touchcancel', onTouchEnd, { passive: false });

    return () => {
      stage.removeEventListener('touchstart', onTouchStart);
      stage.removeEventListener('touchmove', onTouchMove);
      stage.removeEventListener('touchend', onTouchEnd);
      stage.removeEventListener('touchcancel', onTouchEnd);
    };
  }, [triggerMove, updateWorldTransform]);

  // -------------------------------------------------------------
  // DESKTOP MOUSE EVENT SYSTEM (Computer click & drag)
  // -------------------------------------------------------------
  useEffect(() => {
    const stage = stageRef.current;
    if (!stage) return;

    let isMouseDown = false;
    let mouseOrbitStart: { x: number; y: number } | null = null;
    let mouseFaceDrag: {
      startX: number;
      startY: number;
      cubiePos: [number, number, number];
      face: FaceName;
    } | null = null;

    const onMouseDown = (e: MouseEvent) => {
      if (e.button !== 0) return; // Left click only

      const target = e.target as HTMLElement;
      const faceEl = target.closest('[data-face]') as HTMLElement | null;

      if (faceEl && !activeRotationRef.current) {
        const face = faceEl.getAttribute('data-face') as FaceName;
        const posStr = faceEl.getAttribute('data-pos');
        if (face && posStr) {
          const [px, py, pz] = posStr.split(',').map(Number);
          mouseFaceDrag = {
            startX: e.clientX,
            startY: e.clientY,
            cubiePos: [px, py, pz],
            face,
          };
          isMouseDown = true;
          return;
        }
      }

      isMouseDown = true;
      mouseOrbitStart = { x: e.clientX, y: e.clientY };
      if (worldRef.current) {
        worldRef.current.style.transition = 'none';
      }
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isMouseDown) return;

      // Mouse slice turn
      if (mouseFaceDrag) {
        const dx = e.clientX - mouseFaceDrag.startX;
        const dy = e.clientY - mouseFaceDrag.startY;

        if (Math.abs(dx) > DRAG_THRESHOLD || Math.abs(dy) > DRAG_THRESHOLD) {
          const { face, cubiePos } = mouseFaceDrag;
          const move = getRotationFromDrag(face, cubiePos, dx, dy);
          if (move) {
            triggerMove(move.axis, move.slice, move.direction);
          }
          mouseFaceDrag = null;
        }
        return;
      }

      // Mouse camera orbit
      if (mouseOrbitStart) {
        const dx = e.clientX - mouseOrbitStart.x;
        const dy = e.clientY - mouseOrbitStart.y;
        mouseOrbitStart = { x: e.clientX, y: e.clientY };

        rotationRef.current.x = Math.max(-82, Math.min(82, rotationRef.current.x - dy * 0.42));
        rotationRef.current.y = (rotationRef.current.y + dx * 0.42) % 360;

        if (!rafIdRef.current) {
          rafIdRef.current = requestAnimationFrame(() => {
            updateWorldTransform(false);
            rafIdRef.current = null;
          });
        }
      }
    };

    const onMouseUp = () => {
      isMouseDown = false;
      mouseOrbitStart = null;
      mouseFaceDrag = null;
    };

    stage.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);

    return () => {
      stage.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
    };
  }, [triggerMove, updateWorldTransform]);

  // Mouse Wheel Zoom for Computers
  const handleWheel = (e: React.WheelEvent<HTMLDivElement>) => {
    e.preventDefault();
    const delta = -e.deltaY * 0.0015;
    const newZoom = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, zoomScaleRef.current + delta));
    zoomScaleRef.current = newZoom;
    updateWorldTransform(false);
  };

  const axisIndex = activeRotation ? (activeRotation.axis === 'x' ? 0 : activeRotation.axis === 'y' ? 1 : 2) : -1;

  const isCubieInRotation = (cubie: CubieState): boolean => {
    if (!activeRotation || axisIndex === -1) return false;
    return Math.round(cubie.position[axisIndex]) === activeRotation.slice;
  };

  const rotatingCubies = activeRotation ? cubeState.filter(isCubieInRotation) : [];
  const staticCubies = activeRotation ? cubeState.filter(c => !isCubieInRotation(c)) : cubeState;

  const animClass = activeRotation
    ? `anim-rotate-${activeRotation.axis}-${activeRotation.direction === 1 ? 'cw' : 'ccw'}`
    : '';

  return (
    <div
      ref={stageRef}
      id="rubik-cube-stage"
      className="w-full h-full flex items-center justify-center touch-none select-none relative overflow-hidden cursor-grab active:cursor-grabbing"
      onWheel={handleWheel}
    >
      {/* Centered 3D World */}
      <div
        ref={worldRef}
        className="relative preserve-3d will-change-transform"
        style={{
          width: `${cubieSize}px`,
          height: `${cubieSize}px`,
          transform: `scale3d(${zoomScaleRef.current}, ${zoomScaleRef.current}, ${zoomScaleRef.current}) rotateX(${rotationRef.current.x}deg) rotateY(${rotationRef.current.y}deg)`,
        }}
      >
        {/* Soft Ground Shadow scaled with the cube */}
        <div
          className="absolute pointer-events-none rounded-full"
          style={{
            width: `${cubieSize * 3.4}px`,
            height: `${cubieSize * 3.4}px`,
            left: `-${cubieSize * 1.2}px`,
            top: `-${cubieSize * 1.2}px`,
            background: 'radial-gradient(circle, rgba(0,0,0,0.65) 0%, rgba(0,0,0,0.2) 42%, rgba(0,0,0,0) 68%)',
            transform: `rotateX(90deg) translateZ(${cubieSize * 2.3}px)`,
          }}
        />

        {/* Static Cubies */}
        {staticCubies.map(cubie => (
          <Cubie
            key={cubie.id}
            id={cubie.id}
            position={cubie.position}
            colors={cubie.colors}
            size={cubieSize}
            gap={CUBE_GAP}
          />
        ))}

        {/* Rotating Slice */}
        {activeRotation && (
          <div
            className={`absolute top-0 left-0 w-full h-full preserve-3d will-change-transform ${animClass}`}
            onAnimationEnd={finishActiveRotation}
            style={{
              transformOrigin: 'center center 0px',
            }}
          >
            {rotatingCubies.map(cubie => (
              <Cubie
                key={cubie.id}
                id={cubie.id}
                position={cubie.position}
                colors={cubie.colors}
                size={cubieSize}
                gap={CUBE_GAP}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
});

export default Cube;
