import React from 'react';
import { CubieState, Color, COLOR_STYLES, FaceName, ALL_FACES } from '../types';

interface CubieProps extends Omit<CubieState, 'id'> {
  id?: number;
  size: number;
  gap: number;
  onFacePointerDown?: (e: React.PointerEvent<HTMLDivElement>, position: [number, number, number], face: FaceName) => void;
}

const faceTransforms: Record<FaceName, string> = {
  F: 'translateZ(HALF_PX)',
  B: 'rotateY(180deg) translateZ(HALF_PX)',
  R: 'rotateY(90deg) translateZ(HALF_PX)',
  L: 'rotateY(-90deg) translateZ(HALF_PX)',
  U: 'rotateX(90deg) translateZ(HALF_PX)',
  D: 'rotateX(-90deg) translateZ(HALF_PX)',
};

export const Cubie: React.FC<CubieProps> = React.memo(({ position, colors, size, gap, onFacePointerDown }) => {
  const totalStep = size + gap;
  const [x, y, z] = position;
  const half = size / 2;
  const isCenter = (Math.abs(x) + Math.abs(y) + Math.abs(z)) === 1;

  // Crisp sticker layout math - exactly ~3.5px black plastic border
  const margin = Math.max(3, Math.round(size * 0.065));
  const stickerW = size - margin * 2;
  const borderRadius = Math.max(4, Math.round(size * 0.1));

  return (
    <div
      className="absolute top-0 left-0 preserve-3d"
      style={{
        width: `${size}px`,
        height: `${size}px`,
        transform: `translate3d(${x * totalStep}px, ${y * totalStep}px, ${z * totalStep}px)`,
      }}
    >
      {ALL_FACES.map(face => {
        const color = colors[face];
        const hasSticker = !!color;
        const transform = faceTransforms[face].replace('HALF_PX', `${half}px`);

        if (!hasSticker) {
          return (
            <div
              key={face}
              className="absolute inset-0 pointer-events-none"
              style={{
                transform,
                backgroundColor: '#0c0e12',
                border: '1px solid #060709',
                backfaceVisibility: 'hidden',
                WebkitBackfaceVisibility: 'hidden',
              }}
            />
          );
        }

        const sticker = COLOR_STYLES[color as Color];

        return (
          <div
            key={face}
            data-face={face}
            data-pos={`${x},${y},${z}`}
            onPointerDown={(e) => {
              onFacePointerDown?.(e, position, face);
            }}
            className="absolute inset-0 cursor-pointer active:brightness-95 cubie-interactive-face"
            style={{
              transform,
              backgroundColor: '#0d0f14',
              border: '1px solid #060709',
              backfaceVisibility: 'hidden',
              WebkitBackfaceVisibility: 'hidden',
            }}
          >
            {/* Crisp Sticker */}
            <div
              className="absolute pointer-events-none"
              style={{
                top: `${margin}px`,
                left: `${margin}px`,
                width: `${stickerW}px`,
                height: `${stickerW}px`,
                borderRadius: `${borderRadius}px`,
                background: sticker.bg,
                border: `1px solid ${sticker.border}`,
                boxShadow: `inset 0 1px 1.5px ${sticker.highlight}, 0 1px 2px rgba(0,0,0,0.6)`,
              }}
            >
              {/* White Center Rubik Logo */}
              {color === 'W' && isCenter && (
                <div className="w-full h-full flex flex-col items-center justify-center select-none pointer-events-none opacity-85">
                  <div className="w-3.5 h-3.5 border-[1.5px] border-neutral-900 rotate-45 flex items-center justify-center">
                    <div className="w-1 h-1 bg-neutral-900 rounded-full" />
                  </div>
                  <span className="text-[6.5px] font-black tracking-tighter text-neutral-900 mt-0.5 leading-none">
                    RUBIK
                  </span>
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
});

export default Cubie;
