import React, { useState } from 'react';
import { MoveNotation, STANDARD_MOVES, Axis } from '../types';
import {
  RotateCcw,
  Undo2,
  Shuffle,
  Volume2,
  VolumeX,
  Eye,
  ChevronDown,
  ChevronUp,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';

interface FaceControlsProps {
  onMove: (axis: Axis, slice: number, direction: 1 | -1) => void;
  onUndo: () => void;
  onScramble: () => void;
  onReset: () => void;
  onViewChange: (view: 'isometric' | 'front' | 'top' | 'right') => void;
  onZoomIn: () => void;
  onZoomOut: () => void;
  canUndo: boolean;
  isScrambling: boolean;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

const PRIMARY_FACES = [
  { face: 'U', border: 'border-slate-300', text: 'text-white', bg: 'bg-slate-800/80 hover:bg-slate-700', label: 'Up (White)', keyHint: 'U' },
  { face: 'L', border: 'border-orange-500', text: 'text-orange-400', bg: 'bg-orange-950/40 hover:bg-orange-900/50', label: 'Left (Orange)', keyHint: 'L' },
  { face: 'F', border: 'border-emerald-500', text: 'text-emerald-400', bg: 'bg-emerald-950/40 hover:bg-emerald-900/50', label: 'Front (Green)', keyHint: 'F' },
  { face: 'R', border: 'border-red-500', text: 'text-red-400', bg: 'bg-red-950/40 hover:bg-red-900/50', label: 'Right (Red)', keyHint: 'R' },
  { face: 'B', border: 'border-blue-500', text: 'text-blue-400', bg: 'bg-blue-950/40 hover:bg-blue-900/50', label: 'Back (Blue)', keyHint: 'B' },
  { face: 'D', border: 'border-amber-400', text: 'text-amber-300', bg: 'bg-amber-950/40 hover:bg-amber-900/50', label: 'Down (Yellow)', keyHint: 'D' },
];

export const FaceControls: React.FC<FaceControlsProps> = ({
  onMove,
  onUndo,
  onScramble,
  onReset,
  onViewChange,
  onZoomIn,
  onZoomOut,
  canUndo,
  isScrambling,
  soundEnabled,
  onToggleSound,
}) => {
  const [isMinimized, setIsMinimized] = useState<boolean>(false);
  const [isPrime, setIsPrime] = useState<boolean>(false);
  const [showViews, setShowViews] = useState<boolean>(false);

  const handleFaceClick = (face: string) => {
    const notation = (isPrime ? `${face}'` : face) as MoveNotation;
    const move = STANDARD_MOVES[notation];
    if (move) {
      onMove(move.axis, move.slice, move.direction);
    }
  };

  // Minimized Compact Bottom Bar
  if (isMinimized) {
    return (
      <div className="w-full max-w-xs sm:max-w-sm md:max-w-md mx-auto flex items-center justify-between gap-2 px-3 py-1.5 rounded-2xl bg-[#11131a] border border-[#242836] shadow-2xl pointer-events-auto">
        {/* Expand / Maximize Button */}
        <button
          id="btn-expand-controls"
          onClick={() => setIsMinimized(false)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md shadow-blue-600/30 active:scale-95 transition"
          title="Open full face controls"
        >
          <ChevronUp className="w-4 h-4" />
          <span>Face Controls</span>
        </button>

        {/* Quick Actions while minimized */}
        <div className="flex items-center gap-1">
          <button
            id="min-btn-undo"
            onClick={onUndo}
            disabled={!canUndo || isScrambling}
            className="p-1.5 rounded-lg text-neutral-300 bg-[#1a1d27] hover:bg-[#262b3a] border border-[#2d3345] disabled:opacity-30 transition"
            title="Undo move"
          >
            <Undo2 className="w-3.5 h-3.5" />
          </button>

          <button
            id="min-btn-scramble"
            onClick={onScramble}
            disabled={isScrambling}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white transition active:scale-95 disabled:opacity-50"
            title="Scramble cube"
          >
            <Shuffle className={`w-3 h-3 ${isScrambling ? 'animate-spin' : ''}`} />
            <span className="text-[11px]">Scramble</span>
          </button>

          <button
            id="min-btn-reset"
            onClick={onReset}
            disabled={isScrambling}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white bg-[#1a1d27] hover:bg-[#262b3a] border border-[#2d3345] transition"
            title="Reset cube"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-sm sm:max-w-md md:max-w-xl lg:max-w-2xl mx-auto flex flex-col gap-1.5 px-2.5 sm:px-4 pointer-events-auto">
      {/* Optional Camera Presets & Quick Zoom Panel */}
      {showViews && (
        <div className="flex items-center justify-between gap-1.5 p-1.5 rounded-xl bg-[#12151f] border border-[#2a3045] shadow-xl animate-in fade-in slide-in-from-bottom-2 duration-150">
          <div className="flex items-center gap-1">
            <span className="text-[10px] font-semibold uppercase tracking-wider text-neutral-400 pl-1.5 hidden sm:inline">
              Angles:
            </span>
            <button
              onClick={() => { onViewChange('isometric'); setShowViews(false); }}
              className="px-2 py-1 text-xs font-medium rounded-lg bg-[#1a1d27] text-neutral-200 hover:bg-[#262b3a] active:scale-95 transition"
            >
              Default 3D
            </button>
            <button
              onClick={() => { onViewChange('front'); setShowViews(false); }}
              className="px-2 py-1 text-xs font-medium rounded-lg bg-[#1a1d27] text-neutral-200 hover:bg-[#262b3a] active:scale-95 transition"
            >
              Front
            </button>
            <button
              onClick={() => { onViewChange('top'); setShowViews(false); }}
              className="px-2 py-1 text-xs font-medium rounded-lg bg-[#1a1d27] text-neutral-200 hover:bg-[#262b3a] active:scale-95 transition"
            >
              Top
            </button>
            <button
              onClick={() => { onViewChange('right'); setShowViews(false); }}
              className="px-2 py-1 text-xs font-medium rounded-lg bg-[#1a1d27] text-neutral-200 hover:bg-[#262b3a] active:scale-95 transition"
            >
              Right
            </button>
          </div>

          {/* Quick Zoom Buttons in View menu */}
          <div className="flex items-center gap-1 border-l border-neutral-800 pl-1.5">
            <button
              id="btn-zoom-out"
              onClick={onZoomOut}
              className="p-1.5 rounded-lg bg-[#1a1d27] text-neutral-300 hover:bg-[#262b3a] active:scale-95 transition"
              title="Zoom Out (or pinch with 2 fingers)"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <button
              id="btn-zoom-in"
              onClick={onZoomIn}
              className="p-1.5 rounded-lg bg-[#1a1d27] text-neutral-300 hover:bg-[#262b3a] active:scale-95 transition"
              title="Zoom In (or pinch with 2 fingers)"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Main Face Navigation Dock */}
      <div className="flex flex-col gap-1.5 sm:gap-2 p-2 sm:p-2.5 rounded-2xl bg-[#10121a] border border-[#222736] shadow-2xl">
        {/* Top Header Row of the Dock: Prime Toggle, Actions, and Minimize Button */}
        <div className="flex items-center justify-between gap-1 flex-wrap sm:flex-nowrap">
          {/* Prime (Clockwise vs CCW) Toggle */}
          <button
            id="toggle-prime-direction"
            onClick={() => setIsPrime(p => !p)}
            className={`flex items-center gap-1 sm:gap-1.5 px-2 sm:px-2.5 py-1 sm:py-1.5 rounded-xl text-[11px] sm:text-xs font-bold transition-all shadow-sm ${
              isPrime
                ? 'bg-amber-400 text-neutral-950 ring-2 ring-amber-300 font-extrabold shadow-amber-400/25'
                : 'bg-[#1a1d27] text-neutral-300 hover:bg-[#262b3a] border border-[#2d3345]'
            }`}
            title="Toggle Clockwise or Inverse (') Prime turns (or hold Shift on keyboard)"
          >
            <span className="tracking-tight">{isPrime ? "Inverse ( ' )" : 'Standard (CW)'}</span>
          </button>

          {/* Action buttons: Undo, Camera, Sound, Scramble, Reset, MINIMIZE */}
          <div className="flex items-center gap-1 sm:gap-1.5">
            {/* Undo */}
            <button
              id="btn-undo-move"
              onClick={onUndo}
              disabled={!canUndo || isScrambling}
              className="p-1.5 sm:p-2 rounded-xl text-neutral-300 bg-[#1a1d27] hover:bg-[#262b3a] border border-[#2d3345] disabled:opacity-30 disabled:pointer-events-none transition active:scale-95"
              title="Undo last move (Z or Ctrl+Z)"
              aria-label="Undo move"
            >
              <Undo2 className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            </button>

            {/* Camera View Switcher */}
            <button
              id="btn-camera-view"
              onClick={() => setShowViews(v => !v)}
              className={`p-1.5 sm:p-2 rounded-xl text-neutral-300 border transition active:scale-95 ${
                showViews
                  ? 'bg-blue-600 text-white border-blue-500'
                  : 'bg-[#1a1d27] hover:bg-[#262b3a] border-[#2d3345]'
              }`}
              title="Camera presets & zoom"
              aria-label="Camera presets & zoom"
            >
              <Eye className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            </button>

            {/* Sound Toggle */}
            <button
              id="btn-toggle-sound"
              onClick={onToggleSound}
              className="p-1.5 sm:p-2 rounded-xl text-neutral-300 bg-[#1a1d27] hover:bg-[#262b3a] border border-[#2d3345] transition active:scale-95"
              title={soundEnabled ? 'Mute click sound' : 'Enable click sound'}
              aria-label="Toggle sound"
            >
              {soundEnabled ? <Volume2 className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-400" /> : <VolumeX className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-neutral-500" />}
            </button>

            {/* Scramble */}
            <button
              id="btn-scramble-cube"
              onClick={onScramble}
              disabled={isScrambling}
              className="flex items-center gap-1 px-2 sm:px-2.5 md:px-3 py-1 sm:py-1.5 rounded-xl text-[11px] sm:text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white shadow-md shadow-blue-600/30 transition active:scale-95 disabled:opacity-50"
              title="Scramble cube (Spacebar)"
            >
              <Shuffle className={`w-3 h-3 sm:w-3.5 sm:h-3.5 ${isScrambling ? 'animate-spin' : ''}`} />
              <span className="hidden xs:inline sm:inline">Scramble</span>
            </button>

            {/* Reset */}
            <button
              id="btn-reset-cube"
              onClick={onReset}
              disabled={isScrambling}
              className="p-1.5 sm:p-2 rounded-xl text-neutral-400 hover:text-white bg-[#1a1d27] hover:bg-[#262b3a] border border-[#2d3345] transition active:scale-95 disabled:opacity-30"
              title="Reset cube"
              aria-label="Reset cube"
            >
              <RotateCcw className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            </button>

            {/* Minimize Button */}
            <button
              id="btn-minimize-controls"
              onClick={() => setIsMinimized(true)}
              className="p-1.5 sm:p-2 rounded-xl text-neutral-400 hover:text-white bg-[#1a1d27] hover:bg-neutral-800 border border-[#2d3345] transition active:scale-95 flex items-center justify-center ml-0.5"
              title="Minimize bottom bar"
              aria-label="Minimize bottom bar"
            >
              <ChevronDown className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-neutral-300" />
            </button>
          </div>
        </div>

        {/* 6 Face Buttons Grid (Responsive across mobile, pad & computer) */}
        <div className="grid grid-cols-6 gap-1 sm:gap-1.5 pt-0.5">
          {PRIMARY_FACES.map(({ face, border, text, bg, label, keyHint }) => {
            const displayName = isPrime ? `${face}'` : face;
            return (
              <button
                key={face}
                id={`btn-face-${face}`}
                onClick={() => handleFaceClick(face)}
                disabled={isScrambling}
                className={`
                  h-10 sm:h-11 md:h-12 flex flex-col items-center justify-center
                  rounded-xl font-black text-sm sm:text-base md:text-lg
                  border ${border} ${text} ${bg}
                  transition-transform duration-75
                  active:scale-95 active:brightness-125
                  shadow-sm
                  disabled:opacity-30 disabled:pointer-events-none relative group
                `}
                title={`Turn ${label} ${isPrime ? 'Counter-Clockwise' : 'Clockwise'} (Key: ${keyHint})`}
              >
                <span className="leading-none">{displayName}</span>
                {/* Desktop keyboard shortcut hint */}
                <span className="hidden md:inline-block text-[8px] font-mono opacity-50 font-normal leading-none mt-0.5">
                  [{keyHint}]
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default FaceControls;
