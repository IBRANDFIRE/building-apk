import { useState, useCallback, useMemo } from 'react';
import { CubeState, Axis, FaceName, Color, FaceRotation, ALL_FACES } from '../types';

// Generate all 27 cubie positions (-1, 0, 1 for x, y, z)
const CUBIE_POSITIONS: Array<[number, number, number]> = [];
for (let x = -1; x <= 1; x++) {
  for (let y = -1; y <= 1; y++) {
    for (let z = -1; z <= 1; z++) {
      CUBIE_POSITIONS.push([x, y, z]);
    }
  }
}

export const getInitialCubieColors = (pos: [number, number, number]): Partial<Record<FaceName, Color>> => {
  const [x, y, z] = pos;
  const colors: Partial<Record<FaceName, Color>> = {};
  if (z === 1) colors.F = 'G';  // Front: Green
  if (z === -1) colors.B = 'B'; // Back: Blue
  if (y === -1) colors.U = 'W'; // Up: White (CSS -Y is UP)
  if (y === 1) colors.D = 'Y';  // Down: Yellow (CSS +Y is DOWN)
  if (x === -1) colors.L = 'O'; // Left: Orange
  if (x === 1) colors.R = 'R';  // Right: Red
  return colors;
};

export const createInitialState = (): CubeState => {
  return CUBIE_POSITIONS.map((pos, i) => ({
    id: i,
    position: [...pos] as [number, number, number],
    colors: getInitialCubieColors(pos),
  }));
};

/**
 * Calculates new 3D position of a point [x, y, z] after a 90° rotation
 * around the given axis in the specified direction (+1 or -1).
 * Aligned precisely with CSS 3D: rotateX, rotateY, rotateZ.
 */
export const rotatePosition = (
  [x, y, z]: [number, number, number],
  axis: Axis,
  direction: 1 | -1
): [number, number, number] => {
  switch (axis) {
    case 'x':
      // Rotate around X: X unchanged, Y and Z rotate
      return [x, -direction * z, direction * y];
    case 'y':
      // Rotate around Y: Y unchanged, Z and X rotate
      return [direction * z, y, -direction * x];
    case 'z':
      // Rotate around Z: Z unchanged, X and Y rotate
      return [-direction * y, direction * x, z];
  }
};

/**
 * Maps faces to their new orientation when rotated 90° around an axis.
 */
export const getFaceMapping = (
  axis: Axis,
  direction: 1 | -1
): Partial<Record<FaceName, FaceName>> => {
  if (axis === 'x') {
    return direction === 1
      ? { U: 'B', B: 'D', D: 'F', F: 'U' }
      : { B: 'U', D: 'B', F: 'D', U: 'F' };
  }
  if (axis === 'y') {
    return direction === 1
      ? { F: 'R', R: 'B', B: 'L', L: 'F' }
      : { R: 'F', B: 'R', L: 'B', F: 'L' };
  }
  // axis === 'z'
  return direction === 1
    ? { U: 'R', R: 'D', D: 'L', L: 'U' }
    : { R: 'U', D: 'R', L: 'D', U: 'L' };
};

/**
 * Evaluates whether every face of the cube has uniform colors.
 */
export const checkIsSolved = (cube: CubeState): boolean => {
  const faceColors: Record<FaceName, Color[]> = {
    F: [],
    B: [],
    U: [],
    D: [],
    L: [],
    R: [],
  };

  for (const cubie of cube) {
    for (const face of ALL_FACES) {
      const color = cubie.colors[face];
      if (color) {
        faceColors[face].push(color);
      }
    }
  }

  for (const face of ALL_FACES) {
    const list = faceColors[face];
    if (list.length !== 9) return false;
    const first = list[0];
    if (!list.every(c => c === first)) return false;
  }

  return true;
};

export const useCubeState = () => {
  const [cubeState, setCubeState] = useState<CubeState>(createInitialState);
  const [moveCount, setMoveCount] = useState<number>(0);
  const [history, setHistory] = useState<FaceRotation[]>([]);
  const [isScrambled, setIsScrambled] = useState<boolean>(false);

  const rotateFace = useCallback((axis: Axis, slice: number, direction: 1 | -1, recordHistory = true) => {
    setCubeState(prevState => {
      const axisIndex = axis === 'x' ? 0 : axis === 'y' ? 1 : 2;
      const faceMap = getFaceMapping(axis, direction);

      return prevState.map(cubie => {
        // Only transform cubies in the target slice
        if (Math.round(cubie.position[axisIndex]) !== slice) {
          return cubie;
        }

        const newPos = rotatePosition(cubie.position, axis, direction);
        const newColors: Partial<Record<FaceName, Color>> = {};

        for (const [face, color] of Object.entries(cubie.colors)) {
          if (color) {
            const currentFace = face as FaceName;
            const destinationFace = faceMap[currentFace] ?? currentFace;
            newColors[destinationFace] = color as Color;
          }
        }

        return {
          ...cubie,
          position: newPos.map(v => Math.round(v)) as [number, number, number],
          colors: newColors,
        };
      });
    });

    if (recordHistory) {
      setHistory(prev => [...prev, { axis, slice, direction }]);
      setMoveCount(c => c + 1);
    }
  }, []);

  const undo = useCallback((): FaceRotation | null => {
    if (history.length === 0) return null;
    const lastMove = history[history.length - 1];
    setHistory(prev => prev.slice(0, -1));
    const inverseDirection = (lastMove.direction === 1 ? -1 : 1) as (1 | -1);
    rotateFace(lastMove.axis, lastMove.slice, inverseDirection, false);
    setMoveCount(c => Math.max(0, c - 1));
    return {
      axis: lastMove.axis,
      slice: lastMove.slice,
      direction: inverseDirection,
    };
  }, [history, rotateFace]);

  const reset = useCallback(() => {
    setCubeState(createInitialState());
    setMoveCount(0);
    setHistory([]);
    setIsScrambled(false);
  }, []);

  const isSolved = useMemo(() => {
    return checkIsSolved(cubeState);
  }, [cubeState]);

  return {
    cubeState,
    rotateFace,
    undo,
    reset,
    moveCount,
    historyLength: history.length,
    isSolved,
    isScrambled,
    setIsScrambled,
  };
};
